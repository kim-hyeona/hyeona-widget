# 개인 루틴 · LunaRoutine (Android)

독립 안드로이드 앱 / 실제 홈 화면 달력형 위젯 / 생리주기 및 체중 기록 / 날짜별 개인 루틴 / 개인 알림 / Notion 수동 동기화.

- Android 8.0(API 26) 이상
- `gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
- 별도 코드베이스 및 Android 패키지 `com.hyeona.lunaroutine`; 기존 위젯과 연동하거나 수정하지 않습니다.
- 빌드용 GitHub Actions를 포함합니다.
- 앱 초기 데이터는 비어 있습니다. 캘린더의 수치는 사용자 입력으로 계산하며 실제 배란일을 확정하지 않습니다.
- 💊/🍦는 사용자가 직접 날짜를 등록한 개인 일정만 나타냅니다. 주기만으로 의약품 사용일/용량을 결정하지 않습니다.
- 생리 종료 다음 날부터 7일 동안 매일 오전 9:30에 '오늘의 루틴을 확인하세요' 알림을 보냅니다. Android 13+ 알림 권한 허용 필요.
- Notion: 새로운 프로젝트 전용 data_source_id `c22705c7-81e4-4040-bb72-7e18364d451c`. Notion 개발자 통합(https://www.notion.so/profile/integrations) 발급 후 이 DB를 해당 통합과 공유하고, 앱 설정 화면에 토큰을 입력한 후 동기화하세요. **사용자 API 토큰을 앱 소스 또는 GitHub에 추가하지 마세요**.
- 데이터는 휴대폰 로컬에 보관되고, '동기화' 버튼 클릭 시 Notion API로 업로드/조회합니다. 여러 기기에서 동시 편집 시 수동으로 병합됩니다.

**보안 주의**: 설정에 입력하는 Notion integration token은 Android 앱의 private SharedPreferences에 저장됩니다. 다른 앱에서 바로 읽을 수는 없지만, 루팅/기기 침해에 대한 강한 보호 수준은 아닙니다. 개인 의료·생활기록을 다루므로 중요한 데이터는 잠금된 개인 기기에서 사용하세요.
