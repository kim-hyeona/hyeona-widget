package com.hyeona.lunaroutine;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import android.view.WindowManager;
import org.json.JSONObject;
import java.util.concurrent.*;

public class MainActivity extends Activity {
  WebView web;
  boolean unlocked=false,asking=false;
  ExecutorService executor=Executors.newSingleThreadExecutor();
  android.content.SharedPreferences pref(){return getSharedPreferences("luna",MODE_PRIVATE);}
  @SuppressLint("SetJavaScriptEnabled") @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(0xFFFFEFF4);getWindow().setNavigationBarColor(0xFFFFEFF4);
    getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    if(pref().getBoolean("secure",true))getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    web=new WebView(this);web.setBackgroundColor(0xFFFFEFF4);web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(false);
    web.getSettings().setAllowFileAccessFromFileURLs(false);web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.addJavascriptInterface(new Bridge(),"AndroidBridge");web.setWebViewClient(new WebViewClient());web.loadUrl("file:///android_asset/index.html");setContentView(web);
    ReminderReceiver.schedule(this);
    if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
  }
  @Override protected void onResume(){super.onResume();if(!unlocked&&!asking&&pref().getBoolean("appLock",false)){
    KeyguardManager km=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
    if(km!=null&&km.isDeviceSecure()){Intent i=km.createConfirmDeviceCredentialIntent("개인 루틴","잠금을 해제해 주세요");if(i!=null){asking=true;startActivityForResult(i,42);}}
  }}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==42){asking=false;if(result==RESULT_OK)unlocked=true;else finish();}}
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
  void callback(boolean ok,String msg){runOnUiThread(()->web.evaluateJavascript("window.onNotionResult("+ok+","+JSONObject.quote(msg)+")",null));}
  class Bridge {
    @JavascriptInterface public String getLocal(){return pref().getString("data","{\"periods\":[],\"weights\":[],\"routines\":[],\"cycleLength\":28}");}
    @JavascriptInterface public void putLocal(String json){try{new JSONObject(json);pref().edit().putString("data",json).apply();runOnUiThread(()->WeekWidget.updateAll(MainActivity.this));}catch(Exception ignore){}}
    @JavascriptInterface public String getSettings(){JSONObject j=new JSONObject();try{j.put("secure",pref().getBoolean("secure",true));j.put("appLock",pref().getBoolean("appLock",false));j.put("notionKey",pref().getString("notionKey",""));j.put("sourceId",pref().getString("sourceId","c22705c7-81e4-4040-bb72-7e18364d451c"));}catch(Exception ignore){}return j.toString();}
    @JavascriptInterface public void updateSettings(String json){try{JSONObject j=new JSONObject(json);pref().edit().putBoolean("secure",j.optBoolean("secure",true)).putBoolean("appLock",j.optBoolean("appLock",false)).putString("notionKey",j.optString("notionKey","")).putString("sourceId",j.optString("sourceId","")).apply();runOnUiThread(()->{if(j.optBoolean("secure",true))getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);});}catch(Exception ignore){}}
    @JavascriptInterface public void syncNotion(String json){executor.execute(()->{try{JSONObject result=new NotionClient(pref().getString("notionKey",""),pref().getString("sourceId","c22705c7-81e4-4040-bb72-7e18364d451c")).sync(new JSONObject(json));pref().edit().putString("data",result.toString()).apply();runOnUiThread(()->WeekWidget.updateAll(MainActivity.this));callback(true,result.toString());}catch(Exception ex){callback(false,ex.getMessage()==null?"연동 실패":ex.getMessage());}});}
  }
}
