package com.hyeona.lunaroutine;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

class NotionClient {
  private final String key,source;
  NotionClient(String key,String source){this.key=key.trim();this.source=source.trim();}
  private JSONObject req(String method,String path,JSONObject data)throws Exception {
    HttpURLConnection c=(HttpURLConnection)new URL("https://api.notion.com/v1/"+path).openConnection();c.setRequestMethod(method);c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Notion-Version","2025-09-03");c.setRequestProperty("Content-Type","application/json");
    if(data!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(data.toString().getBytes(StandardCharsets.UTF_8));}}
    int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();StringBuilder s=new StringBuilder();if(in!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String l;while((l=r.readLine())!=null)s.append(l);}
    c.disconnect();JSONObject j=new JSONObject(s.length()==0?"{}":s.toString());if(code>=400)throw new Exception("Notion HTTP "+code+" · "+j.optString("message","연결을 확인해 주세요"));return j;
  }
  private JSONObject text(String content){return new JSONObject().put("text",new JSONObject().put("content",content));}
  private JSONObject props(JSONObject item,String kind)throws Exception {
    String d="periods".equals(kind)?item.getString("start"):item.getString("date"),name="periods".equals(kind)?"생리":"weights".equals(kind)?"체중":"제품";
    JSONObject p=new JSONObject();p.put("기록",new JSONObject().put("title",new JSONArray().put(text(name+" "+d))));p.put("기록ID",new JSONObject().put("rich_text",new JSONArray().put(text(item.getString("id")))));p.put("유형",new JSONObject().put("select",new JSONObject().put("name",name)));p.put("일자",new JSONObject().put("date",new JSONObject().put("start",d)));
    if("periods".equals(kind))p.put("종료일",new JSONObject().put("date",new JSONObject().put("start",item.getString("end"))));
    if("weights".equals(kind))p.put("체중(kg)",new JSONObject().put("number",item.getDouble("value")));
    if("routines".equals(kind)){p.put("제품",new JSONObject().put("select",new JSONObject().put("name","pill".equals(item.getString("type"))?"푸에라리아":"프로게스테론크림")));p.put("완료",new JSONObject().put("checkbox",item.optBoolean("done",false)));}return p;
  }
  private String rich(JSONObject p){JSONObject r=p.optJSONObject("기록ID");if(r==null)return "";JSONArray a=r.optJSONArray("rich_text");if(a==null||a.length()==0)return "";return a.optJSONObject(0).optString("plain_text","");}
  private String date(JSONObject p,String name){JSONObject x=p.optJSONObject(name);JSONObject d=x==null?null:x.optJSONObject("date");return d==null?"":d.optString("start","");}
  private JSONObject fromPage(JSONObject page){try {JSONObject p=page.getJSONObject("properties");String id=rich(p);if(id.isEmpty())return null;String kind=p.getJSONObject("유형").getJSONObject("select").getString("name");JSONObject out=new JSONObject().put("id",id);if("생리".equals(kind))out.put("_kind","periods").put("start",date(p,"일자")).put("end",date(p,"종료일"));else if("체중".equals(kind))out.put("_kind","weights").put("date",date(p,"일자")).put("value",p.getJSONObject("체중(kg)").getDouble("number"));else if("제품".equals(kind))out.put("_kind","routines").put("date",date(p,"일자")).put("type","푸에라리아".equals(p.getJSONObject("제품").getJSONObject("select").getString("name"))?"pill":"cream").put("done",p.getJSONObject("완료").getBoolean("checkbox"));else return null;return out;}catch(Exception e){return null;}}
  JSONObject sync(JSONObject local)throws Exception {
    if(key.isEmpty()||source.isEmpty())throw new Exception("설정에서 Notion 통합 토큰을 등록해 주세요.");
    HashMap<String,String> ids=new HashMap<>();HashMap<String,JSONObject> remote=new HashMap<>();String cursor="";
    for(int page=0;page<100;page++){
      JSONObject q=new JSONObject().put("page_size",100);if(!cursor.isEmpty())q.put("start_cursor",cursor);JSONObject res=req("POST","data_sources/"+source+"/query",q);JSONArray arr=res.optJSONArray("results");
      if(arr!=null)for(int i=0;i<arr.length();i++){JSONObject raw=arr.getJSONObject(i),parsed=fromPage(raw);if(parsed!=null){String id=parsed.getString("id");ids.put(id,raw.getString("id"));remote.put(id,parsed);}}
      if(!res.optBoolean("has_more"))break;cursor=res.optString("next_cursor","");if(cursor.isEmpty())break;
    }
    for(String kind:new String[]{"periods","weights","routines"}){
      JSONArray arr=local.optJSONArray(kind);if(arr==null){arr=new JSONArray();local.put(kind,arr);}Set<String> seen=new HashSet<>();
      for(int i=0;i<arr.length();i++){JSONObject rec=arr.getJSONObject(i);String id=rec.optString("id");if(id.isEmpty())continue;seen.add(id);JSONObject prop=props(rec,kind);String remoteId=ids.get(id);
        if(remoteId!=null)req("PATCH","pages/"+remoteId,new JSONObject().put("properties",prop));
        else req("POST","pages",new JSONObject().put("parent",new JSONObject().put("type","data_source_id").put("data_source_id",source)).put("properties",prop));
        Thread.sleep(400);
      }
      for(JSONObject r:remote.values())if(kind.equals(r.optString("_kind"))&&!seen.contains(r.optString("id"))){r.remove("_kind");arr.put(r);}
    }
    return local;
  }
}
