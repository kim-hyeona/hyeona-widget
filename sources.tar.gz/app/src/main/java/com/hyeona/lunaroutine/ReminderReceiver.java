package com.hyeona.lunaroutine;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import java.time.LocalDate;
import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
  static final String CH="daily_routine";
  @Override public void onReceive(Context ctx,Intent intent){
    WeekWidget.updateAll(ctx);if(!WeekWidget.dietDay(WeekWidget.state(ctx),LocalDate.now()))return;
    NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CH,"개인 루틴",NotificationManager.IMPORTANCE_DEFAULT));
    if(Build.VERSION.SDK_INT>=33&&ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
    PendingIntent pi=PendingIntent.getActivity(ctx,11,new Intent(ctx,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification n=new Notification.Builder(ctx,CH).setSmallIcon(R.drawable.app_icon).setContentTitle("오늘의 루틴").setContentText("오늘도 식단 관리 잊지 마세요 ♡").setAutoCancel(true).setContentIntent(pi).build();nm.notify(123,n);
  }
  static void schedule(Context ctx){AlarmManager am=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);PendingIntent pi=PendingIntent.getBroadcast(ctx,1,new Intent(ctx,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Calendar t=Calendar.getInstance();t.set(Calendar.HOUR_OF_DAY,9);t.set(Calendar.MINUTE,30);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);if(t.getTimeInMillis()<=System.currentTimeMillis())t.add(Calendar.DAY_OF_YEAR,1);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}
}
