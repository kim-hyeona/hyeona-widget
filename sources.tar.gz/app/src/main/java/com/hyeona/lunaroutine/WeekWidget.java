package com.hyeona.lunaroutine;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.*;
import java.time.temporal.TemporalAdjusters;

public class WeekWidget extends AppWidgetProvider {
  static final int[] DAYS={R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6};
  static final int[] EMOJIS={R.id.e0,R.id.e1,R.id.e2,R.id.e3,R.id.e4,R.id.e5,R.id.e6};
  static final String[] WEEK={"월","화","수","목","금","토","일"};
  @Override public void onUpdate(Context ctx,AppWidgetManager mgr,int[] ids){for(int id:ids)mgr.updateAppWidget(id,make(ctx));}
  @Override public void onReceive(Context ctx,Intent intent){super.onReceive(ctx,intent);if(Intent.ACTION_DATE_CHANGED.equals(intent.getAction())) updateAll(ctx);}
  static void updateAll(Context ctx){AppWidgetManager mgr=AppWidgetManager.getInstance(ctx);int[] ids=mgr.getAppWidgetIds(new ComponentName(ctx,WeekWidget.class));if(ids.length>0)mgr.updateAppWidget(ids,make(ctx));}
  static JSONObject state(Context ctx){try{return new JSONObject(ctx.getSharedPreferences("luna",0).getString("data","{}"));}catch(Exception e){return new JSONObject();}}
  static boolean dietDay(JSONObject data,LocalDate date){JSONArray a=data.optJSONArray("periods");if(a==null)return false;for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;try{LocalDate end=LocalDate.parse(p.getString("end"));int n=(int)java.time.temporal.ChronoUnit.DAYS.between(end,date);if(n>=1&&n<=7)return true;}catch(Exception ignore){}}return false;}
  static boolean menstruation(JSONObject data,LocalDate date){JSONArray a=data.optJSONArray("periods");if(a==null)return false;for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;try{LocalDate s=LocalDate.parse(p.getString("start")),e=LocalDate.parse(p.getString("end"));if(!date.isBefore(s)&&!date.isAfter(e))return true;}catch(Exception ignore){}}return false;}
  static String routineEmoji(JSONObject data,LocalDate date){JSONArray a=data.optJSONArray("routines");if(a==null)return "";StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);if(r==null||!date.toString().equals(r.optString("date")))continue;if("pill".equals(r.optString("type")))s.append("💊");if("cream".equals(r.optString("type")))s.append("🍦");}return s.toString();}
  static RemoteViews make(Context ctx){RemoteViews v=new RemoteViews(ctx.getPackageName(),R.layout.week_widget);JSONObject data=state(ctx);LocalDate mon=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));v.setTextViewText(R.id.widget_title,"♡ 이번 주 루틴");for(int i=0;i<7;i++){LocalDate d=mon.plusDays(i);v.setTextViewText(DAYS[i],WEEK[i]+" "+d.getDayOfMonth());String e=routineEmoji(data,d);if(menstruation(data,d))e="🩸"+e;if(dietDay(data,d))e=e+"🥗";v.setTextViewText(EMOJIS[i],e.isEmpty()?"·":e);v.setTextColor(DAYS[i],d.equals(LocalDate.now())?0xFFE65B90:0xFF784A5E);}PendingIntent p=PendingIntent.getActivity(ctx,0,new Intent(ctx,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);v.setOnClickPendingIntent(R.id.root,p);return v;}
}
