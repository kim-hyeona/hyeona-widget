package com.hyeona.lunaroutine;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.*;
import java.time.temporal.TemporalAdjusters;

public class WeekWidget extends AppWidgetProvider {
  static final int[] DAYS={R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6};
  static final int[] CELLS={R.id.c0,R.id.c1,R.id.c2,R.id.c3,R.id.c4,R.id.c5,R.id.c6};
  static final int[] NUMS={R.id.n0,R.id.n1,R.id.n2,R.id.n3,R.id.n4,R.id.n5,R.id.n6};
  static final int[] EMOJIS={R.id.e0,R.id.e1,R.id.e2,R.id.e3,R.id.e4,R.id.e5,R.id.e6};
  static final String[] WEEK={"월","화","수","목","금","토","일"};
  @Override public void onUpdate(Context ctx,AppWidgetManager mgr,int[] ids){for(int id:ids)mgr.updateAppWidget(id,make(ctx));}
  @Override public void onReceive(Context ctx,Intent intent){super.onReceive(ctx,intent);if(Intent.ACTION_DATE_CHANGED.equals(intent.getAction())) updateAll(ctx);}
  static void updateAll(Context ctx){AppWidgetManager mgr=AppWidgetManager.getInstance(ctx);int[] ids=mgr.getAppWidgetIds(new ComponentName(ctx,WeekWidget.class));if(ids.length>0)mgr.updateAppWidget(ids,make(ctx));}
  static JSONObject state(Context ctx){try{return new JSONObject(ctx.getSharedPreferences("luna",0).getString("data","{}"));}catch(Exception e){return new JSONObject();}}
  static boolean dietDay(JSONObject data,LocalDate date){JSONArray a=data.optJSONArray("periods");if(a==null)return false;for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;try{LocalDate end=LocalDate.parse(p.getString("end"));int n=(int)java.time.temporal.ChronoUnit.DAYS.between(end,date);if(n>=1&&n<=7)return true;}catch(Exception ignore){}}return false;}
  static boolean menstruation(JSONObject data,LocalDate date){JSONArray a=data.optJSONArray("periods");if(a==null)return false;for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;try{LocalDate s=LocalDate.parse(p.getString("start")),e=LocalDate.parse(p.getString("end"));if(!date.isBefore(s)&&!date.isAfter(e))return true;}catch(Exception ignore){}}return false;}
  static String routineEmoji(JSONObject data,LocalDate date){JSONArray a=data.optJSONArray("routines");if(a==null)return "";StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);if(r==null||!date.toString().equals(r.optString("date")))continue;if("pill".equals(r.optString("type")))s.append("💊");if("cream".equals(r.optString("type")))s.append("🍦");}return s.toString();}
  static RemoteViews make(Context ctx){
    RemoteViews v=new RemoteViews(ctx.getPackageName(),R.layout.week_widget);
    JSONObject data=state(ctx);
    LocalDate today=LocalDate.now();
    LocalDate mon=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    LocalDate sun=mon.plusDays(6);
    v.setTextViewText(R.id.widget_title,"♡ 이번 주 루틴");
    v.setTextViewText(R.id.week_range,mon.getMonthValue()+"."+mon.getDayOfMonth()+" - "+sun.getMonthValue()+"."+sun.getDayOfMonth());
    int count=0;
    for(int i=0;i<7;i++){
      LocalDate d=mon.plusDays(i);
      boolean period=menstruation(data,d),diet=dietDay(data,d),isToday=d.equals(today);
      String routine=routineEmoji(data,d);
      String marker=routine;
      if(marker.isEmpty() && period)marker="●";
      else if(marker.isEmpty() && diet)marker="🥗";
      else if(marker.isEmpty())marker=" ";
      if(!routine.isEmpty()||period||diet)count++;
      v.setTextViewText(DAYS[i],WEEK[i]);
      v.setTextViewText(NUMS[i],String.valueOf(d.getDayOfMonth()));
      v.setTextViewText(EMOJIS[i],marker);
      v.setInt(CELLS[i],"setBackgroundResource",isToday?R.drawable.widget_today_bg:(period?R.drawable.widget_period_bg:(diet?R.drawable.widget_diet_bg:R.drawable.widget_day_bg)));
      v.setTextColor(NUMS[i],isToday?0xFFD24F83:0xFF784458);
      v.setTextColor(EMOJIS[i],period && routine.isEmpty()?0xFFE77EA1:0xFF86566C);
    }
    v.setTextViewText(R.id.week_note,count>0?"이번 주 관리 일정 "+count+"일":"이번 주도 나만의 페이스로 ♡");
    PendingIntent p=PendingIntent.getActivity(ctx,0,new Intent(ctx,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    v.setOnClickPendingIntent(R.id.root,p);
    return v;
  }
}
